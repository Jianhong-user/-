from http import HTTPStatus
import dashscope
import os
from docx import Document

# 设置 dashscope API 密钥
dashscope.api_key = "sk-51d7c246db194b3a8784af888e0b8145"

def calculate_keyword_count(text_length):
    # 如果字数小于等于5000，则返回固定的30个关键字
    if text_length <= 5000:
        return 30
    # 否则，每增加1000字，增加6个关键字
    else:
        extra_keywords = (text_length - 5000) // 1000 * 6
        return 30 + extra_keywords

def process_docx_files_in_directory(directory_path):
    # 检查指定路径是否存在
    if not os.path.exists(directory_path):
        print(f"路径 '{directory_path}' 不存在。")
        return

    # 遍历指定路径下的所有文件
    for filename in os.listdir(directory_path):
        if filename.endswith('.docx') or filename.endswith('.doc'):  # 只处理后缀为 .docx 的文件
            file_path = os.path.join(directory_path, filename)
            process_docx_file(file_path)

def process_docx_file(file_path):
    # 读取 .docx 文件内容
    doc = Document(file_path)
    text = '\n'.join([paragraph.text for paragraph in doc.paragraphs])
    text_length = len(text)

    # 根据文档字数计算关键字数量
    keyword_count = calculate_keyword_count(text_length)

    # 创建处理提示
    prompt = f"""你是一个法律文本处理人员，
会对我给你的文本进行处理。
处理形式：
全部文本，根据主题判断提取{keyword_count}个关键字。(重复的词不要，关键词长度最多只取2~4个字)；
把整理出来的关键词，按照中文词性“名词”和“动词”进行区分,之后用你擅长的方式，生成列表，按照实体、事项、行为、地名、权利、责任、政策、程序、权力、纠纷解决方式等主要类型划分，
最后以关键字、词性、类型这三样为列表的头部，
(关键词后面带有的词性不能清除，依旧用号标注),最终格式例如:
| 关键词 | 词性 | 类型 |
| 居民个人 | (名词) | 实体 |
| 约谈 | (动词) | 权利 |
| 纳税年度 | (名词) | 事项 |
"""

    # 将提示与文本内容结合
    prompt_with_text = f"{prompt}\n{text}"

    # 调用模型处理文本
    response = dashscope.Generation.call(
        model=dashscope.Generation.Models.qwen_turbo,
        prompt=prompt_with_text
    )

    # 检查响应状态码
    if response.status_code == HTTPStatus.OK:
        # 输出文本内容
        print(f"文件 '{file_path}' 处理结果：")
        print(response.output["text"])  # 输出文本
    else:
        # 打印错误信息
        print(f"处理文件 '{file_path}' 时出错：")
        print(f"错误代码: {response.code}")
        print(f"错误消息: {response.message}")

if __name__ == '__main__':
    # 指定包含.docx文件的文件夹路径
    directory_path = r'D:\Legal_text'
    process_docx_files_in_directory(directory_path)