import os
import pandas as pd


def get_summary_files(input_folder):
    """
    获取指定文件夹下所有的Excel文件路径
    """
    return [os.path.join(input_folder, f) for f in os.listdir(input_folder) if f.endswith('.xlsx')]


def merge_sheets(input_folder, output_file, sheet_names):
    """
    合并特定工作薄的内容，并去重。
    :param input_folder: 包含汇总表的文件夹路径
    :param output_file: 输出文件路径
    :param sheet_names: 工作薄名称列表
    """
    # 准备写入器
    writer = pd.ExcelWriter(output_file, engine='xlsxwriter')

    for sheet_name in sheet_names:
        all_data_frames = []
        for file_path in get_summary_files(input_folder):
            try:
                # 添加对工作表存在性的检查
                if sheet_name in pd.ExcelFile(file_path).sheet_names:
                    df = pd.read_excel(file_path, sheet_name=sheet_name, engine='openpyxl')
                    all_data_frames.append(df)
                # else:
                #     print(f"工作表 '{sheet_name}' 不存在于文件 '{file_path}' 中")
            except Exception as e:
                pass
                # print(f"读取文件 '{file_path}' 中的 '{sheet_name}' 工作表时出错: {e}")

        if all_data_frames:
            # 合并DataFrame
            combined_df = pd.concat(all_data_frames, ignore_index=True)
            # 根据需要去重，可根据实际情况调整去重列
            combined_df.drop_duplicates(inplace=True)
            # 写入工作薄
            combined_df.to_excel(writer, sheet_name=sheet_name, index=False)

    # 关闭文件写入器
    writer.close()


if __name__ == '__main__':
    input_folder = r'D:\Legal'  # 包含汇总表的文件夹路径
    output_file = r'D:\Legal\新汇总表.xlsx'  # 最终汇总表的输出位置
    sheet_names = ["关键词", "违法行为", "法律责任"]  # 工作薄名称列表
    merge_sheets(input_folder, output_file, sheet_names)