import os
from openpyxl import load_workbook

# 指定文件夹路径
folder_path = r'D:\Legal_text_result'

# 获取文件夹中所有Excel文件的路径
excel_files = [os.path.join(folder_path, file) for file in os.listdir(folder_path) if file.endswith('.xlsx')]

# 循环处理每个Excel文件
for file in excel_files:
    # 打开Excel文件
    wb = load_workbook(file)

    # 遍历所有工作表
    for ws_name in wb.sheetnames:
        ws = wb[ws_name]  # 获取工作表对象

        # 如果工作表名为'违法行为'，则修改第一行内容
        if ws_name == '法律责任':
            for column in ws.iter_cols(min_row=1, max_row=1):
                for cell in column:
                    cell.value = '法律责任'
            # 保存修改后的文件
            wb.save(file)
            break  # 终止对工作表的遍历，因为我们已经找到并修改了目标工作表