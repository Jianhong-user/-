import os
import pandas as pd

# 输入文件夹路径和输出文件夹路径
input_folder = r'D:\Legal_text_result'
output_folder = r'D:\Legal'

# 确保输出文件夹存在
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

# 读取所有Excel文件并汇总内容
all_data = []
for file_name in os.listdir(input_folder):
    if file_name.endswith('.xlsx'):
        file_path = os.path.join(input_folder, file_name)
        # 读取Excel文件的所有子表
        xls = pd.ExcelFile(file_path)
        for sheet_name in xls.sheet_names:
            # 读取子表内容
            df = pd.read_excel(xls, sheet_name)
            # 添加文件名和子表名作为额外列
            df['法律文件名称'] = file_name.split('.')[0].split('-')[-1]  # 去除“-”前的内容
            df['子表名'] = sheet_name
            all_data.append(df)

# 合并所有数据到一个DataFrame
combined_df = pd.concat(all_data, ignore_index=True)

# 创建汇总表并写入数据
summary_file_name = '法律文本分析汇总表.xlsx'
summary_file_path = os.path.join(output_folder, summary_file_name)
file_counter = 1

while os.path.exists(summary_file_path):
    # 如果文件已经存在，则使用动态变量更改名称
    summary_file_name = f'{file_counter}_法律文本分析汇总表.xlsx'
    summary_file_path = os.path.join(output_folder, summary_file_name)
    file_counter += 1

with pd.ExcelWriter(summary_file_path) as writer:
    # 创建子表
    sub_sheets = ['关键词', '违法行为', '法律责任']
    for sheet_name in sub_sheets:
        sub_df = combined_df[combined_df['子表名'] == sheet_name]
        if sheet_name == '关键词':
            # 在“关键词”工作表中只保留"关键词"、"词性"和"类型"列，并进行去重操作
            sub_df = sub_df.drop_duplicates(subset=['关键词'])
            sub_df = sub_df[['关键词', '词性', '类型']]
        elif sheet_name == '违法行为':
            # 在“违法行为”工作表中，只输出每个文件的违法行为内容的第一行时输出文件名，并在输出文件名前插入一个空行
            first_rows_indices = sub_df.groupby('法律文件名称').head(1).index
            sub_df.loc[~sub_df.index.isin(first_rows_indices), '法律文件名称'] = None
            sub_df.loc[first_rows_indices, '法律文件名称'] = '\n' + sub_df['法律文件名称']
            sub_df = sub_df[['法律文件名称', '违法行为']]
        elif sheet_name == '法律责任':
            # 在“法律责任”工作表中，删除空行和以'请注意'开头的句子
            sub_df = sub_df[sub_df['法律责任'].notna()]  # 删除空行
            sub_df = sub_df[~sub_df['法律责任'].str.startswith('请注意')]  # 删除以'请注意'开头的句子
            sub_df = sub_df[['法律责任']]
            sub_df = sub_df.drop_duplicates()
        sub_df.to_excel(writer, index=False, sheet_name=sheet_name)