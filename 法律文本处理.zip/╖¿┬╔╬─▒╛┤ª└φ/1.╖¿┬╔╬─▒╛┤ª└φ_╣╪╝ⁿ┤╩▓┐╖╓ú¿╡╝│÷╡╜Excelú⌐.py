from http import HTTPStatus
import dashscope
import os
from docx import Document
from openpyxl import load_workbook, Workbook
import logging
from openpyxl.styles import Alignment

# 设置 dashscope API 密钥
dashscope.api_key = "sk-51d7c246db194b3a8784af888e0b8145"

# 配置 logging 模块
logging.basicConfig(level=logging.INFO, format='%(message)s')


def calculate_keyword_count(text_length):
    # 如果字数小于等于1500，则返回固定的45个关键字
    if text_length <= 1500:
        return 45
    # 否则，每增加1000字，增加21个关键字
    else:
        extra_keywords = (text_length - 5000) // 1000 * 21
        return 45 + extra_keywords


def process_docx_files_in_directory(directory_path):
    # 检查指定路径是否存在
    if not os.path.exists(directory_path):
        logging.error(f"路径 '{directory_path}' 不存在。")
        return
    # 遍历指定路径下的所有文件
    for filename in os.listdir(directory_path):
        if filename.endswith('.docx'):  # 只处理后缀为 .docx 的文件
            file_path = os.path.join(directory_path, filename)
            process_docx_file(file_path)


def process_docx_file(file_path):
    # 读取 .docx 文件内容
    doc = Document(file_path)
    text = '\n'.join([paragraph.text for paragraph in doc.paragraphs])

    # 按字数和句号切割文本
    text_segments = []
    current_segment = ""
    for sentence in text.split("。"):
        if len(current_segment) + len(sentence) <= 1500:
            current_segment += sentence + "。"
        else:
            text_segments.append(current_segment)
            current_segment = sentence + "。"
    if current_segment:
        text_segments.append(current_segment)

    # 处理每个文本段
    all_processed_text = []
    for segment in text_segments:
        text_length = len(segment)

        # 跳过不足 500 字的最后一段
        if text_length < 500 and segment == text_segments[-1]:
            continue

        print(f'{file_path}字数:' + f'{text_length}')
        keyword_count = calculate_keyword_count(text_length)
        print(f'{file_path}预计输出关键词数量:' + f'{keyword_count}')

        # 根据文档字数选择模型
        model = dashscope.Generation.Models.qwen_turbo
        if text_length > 8000:
            model = dashscope.Generation.Models.qwen_plus

        # 创建处理提示
        prompt = f"""
        你是一个法律文本处理人员，会对我给你的文本进行处理。
        处理形式：全部文本，根据主题判断提取({keyword_count})个关键字(重复的词不要，关键词长度最多只取2~4个字)；
        把整理出来的关键词，按照中文词性“名词”和“动词”进行区分,之后用你擅长的方式，生成列表，按照实体、事项、行为、地名、权利、责任、政策、程序、权力、纠纷解决方式等主要类型划分，
        最后以关键字、词性、类型这三样为列表的头部，(关键词后面带有的词性不能清除，依旧用号标注),
        最终格式例如:
        | 关键词 | 词性 | 类型 |
        | 居民个人 | (名词) | 实体 |
        | 约谈 | (动词) | 权利 |
        | 纳税年度 | (名词) | 事项 |
        处理文本如下：
"""

        # 将提示与文本内容结合
        prompt_with_text = f"{prompt}\n{segment}"

        # 调用模型处理文本
        response = dashscope.Generation.call(
            model=model,
            # temperature=1.9,
            # repetition_penalty=1.1,
            # top_p=0.01,
            # enable_search=True,
            # top_k=50,
            max_tokens=2000,
            prompt=prompt_with_text
        )

        # 检查响应状态码
        if response.status_code == HTTPStatus.OK:
            processed_text = response.output["text"]
            all_processed_text.append(processed_text)
        else:
            # 打印错误信息
            logging.error(f"处理文件 '{file_path}' 时出错：")
            logging.error(f"错误代码: {response.code}")
            logging.error(f"错误消息: {response.message}")

    # 将所有处理结果写入 Excel
    write_to_excel(file_path, "\n".join(all_processed_text))


def write_to_excel(file_path, processed_text):
    # 找到Excel文件路径
    excel_file_path = os.path.splitext(file_path)[0] + '.xlsx'
    # 检查Excel文件是否存在
    if os.path.exists(excel_file_path):
        wb = load_workbook(excel_file_path)
        if '关键词' in wb.sheetnames:
            ws = wb['关键词']
            ws.delete_rows(2, ws.max_row)  # 删除除第一行外的所有行
        else:
            ws = wb.create_sheet('关键词')

        # 解析处理结果，并写入工作表
        seen_keywords = set()
        current_row = 1
        for segment_result in processed_text.split("\n"):
            for line in segment_result.split("\n"):
                data = line.split("|")
                data = [item.strip() for item in data]  # 去除空格
                data = [item for item in data if item]  # 去除空项
                if len(data) == 3:
                    keyword = data[0]
                    if keyword not in seen_keywords:
                        seen_keywords.add(keyword)
                        row_data = '|'.join(data)
                        logging.info(f"{file_path}: {row_data}")  # 在这里输出每一行数据到控制台
                        for j, item in enumerate(data, start=1):
                            cell = ws.cell(row=current_row, column=j, value=item)
                            if j in (1, 3):  # 第一列和第三列靠左对齐
                                cell.alignment = Alignment(horizontal='left', vertical='center')
                            else:
                                cell.alignment = Alignment(horizontal='center', vertical='center')  # 其他列居中对齐
                        current_row += 1

        # 保存工作簿
        wb.save(excel_file_path)
    else:
        # 创建新的 Excel 文件并写入数据
        wb = Workbook()
        ws = wb.active
        ws.title = '关键词'

        # 解析处理结果，并写入工作表
        seen_keywords = set()
        current_row = 1
        for segment_result in processed_text.split("\n"):
            for line in segment_result.split("\n"):
                data = line.split("|")
                data = [item.strip() for item in data]  # 去除空格
                data = [item for item in data if item]  # 去除空项
                if len(data) == 3:
                    keyword = data[0]
                    if keyword not in seen_keywords:
                        seen_keywords.add(keyword)
                        row_data = '|'.join(data)
                        logging.info(f"{file_path}: {row_data}")  # 在这里输出每一行数据到控制台
                        for j, item in enumerate(data, start=1):
                            cell = ws.cell(row=current_row, column=j, value=item)
                            if j in (1, 3):  # 第一列和第三列靠左对齐
                                cell.alignment = Alignment(horizontal='left', vertical='center')
                            else:
                                cell.alignment = Alignment(horizontal='center', vertical='center')  # 其他列居中对齐
                        current_row += 1

        # 保存工作簿
        wb.save(excel_file_path)


if __name__ == '__main__':
    # 指定包含.docx文件的文件夹路径
    directory_path = r'D:\Legal_text'
    process_docx_files_in_directory(directory_path)