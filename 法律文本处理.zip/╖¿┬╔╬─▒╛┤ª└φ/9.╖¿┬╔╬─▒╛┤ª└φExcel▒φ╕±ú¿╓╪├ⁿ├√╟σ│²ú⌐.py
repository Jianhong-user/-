import os

# 设置目标目录路径
target_dir = r"D:\Legal_text_result"

# 获取目标目录下所有以"3-法律文本分析-"开头的.xlsx文件
excel_files = [f for f in os.listdir(target_dir) if f.startswith("4-法律文本分析-") and f.endswith(".xlsx")]

# 遍历这些Excel文档
for excel_file in excel_files:
    # 移除文件名前的特定字符串
    new_file_name = excel_file.replace("4-法律文本分析-", "")

    # 构建旧文件路径和新文件路径
    old_file_path = os.path.join(target_dir, excel_file)
    new_file_path = os.path.join(target_dir, new_file_name)

    # 更新Excel文档的名称
    try:
        os.rename(old_file_path, new_file_path)
        # 输出修改后的文件名称到控制台
        print(f"文件已重命名为: {new_file_name}")
    except OSError as e:
        # 如果遇到错误，打印错误信息
        print(f"重命名{excel_file}时出错: {e}")