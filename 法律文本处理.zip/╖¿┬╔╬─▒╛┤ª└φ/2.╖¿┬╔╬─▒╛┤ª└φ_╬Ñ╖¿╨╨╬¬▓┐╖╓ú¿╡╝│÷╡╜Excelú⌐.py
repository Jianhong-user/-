import logging
import os
from fileinput import filename
from docx import Document
from openpyxl import Workbook, load_workbook
from http import HTTPStatus
import dashscope

# 设置 dashscope API 密钥
dashscope.api_key = "sk-51d7c246db194b3a8784af888e0b8145"

# 配置日志记录器
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def process_docx_files_in_directory(directory_path):
    # 检查指定路径是否存在
    if not os.path.exists(directory_path):
        logging.error(f"路径 '{directory_path}' 不存在。")
        return

    # 遍历指定路径下的所有文件
    for filename in os.listdir(directory_path):
        if filename.endswith('.docx'):  # 只处理后缀为 .docx 的文件
            file_path = os.path.join(directory_path, filename)
            process_docx_file(file_path)

def process_docx_file(file_path):
    # 创建处理提示
    prompt = f"""你是一个法律文本处理人员，
会对我给你的文本进行处理。
输入：
将内容中的全部的违法行为整理出来，不需要详细到第几条和序号,也不需要其他无关的提示，只需要重点内容。
举例输出：
违法行为
-侮辱国旗、国歌、国徽或者其他有损国旗、国歌、国徽尊严的行为
-
处理文本如下：
"""

    # 读取 .docx 文件内容
    doc = Document(file_path)
    text = '\n'.join([paragraph.text.strip() for paragraph in doc.paragraphs if paragraph.text.strip()])  # 清除空行并拼接文本

    # 将提示与文本内容结合
    prompt_with_text = f"{prompt}\n{text}"

    # 根据文档字数选择模型
    model = dashscope.Generation.Models.qwen_turbo
    if len(text) > 8000:
        model = dashscope.Generation.Models.qwen_plus

    # 调用模型处理文本
    response = dashscope.Generation.call(
        model=model,
        prompt=prompt_with_text
    )

    # 检查响应状态码
    if response.status_code == HTTPStatus.OK:
        # 获取处理结果文本
        processed_text = response.output.get('text', '').strip()

        # 检查处理结果是否为空
        if processed_text:
            # 按行拆分文本
            processed_lines = processed_text.split('\n')

            # 获取文件名（不带扩展名）
            filename_without_extension = os.path.splitext(os.path.basename(file_path))[0]

            # Excel文件名与路径
            excel_filename = filename_without_extension + '.xlsx'
            excel_file_path = os.path.join(os.path.dirname(file_path), excel_filename)

            # 创建或加载工作簿
            if os.path.exists(excel_file_path):
                wb = load_workbook(excel_file_path)
            else:
                logging.warning(f"未找到与 '{filename}' 相同名字的Excel文件，将创建新的Excel文件。")
                wb = Workbook()

            # 创建名为"违法行为"的工作表
            ws = wb.create_sheet("违法行为")

            # 将处理结果逐行写入工作表
            for line in processed_lines:
                ws.append([line])

            # 保存Excel文件
            wb.save(excel_file_path)

            logging.info(f"处理结果已写入 '{excel_file_path}' 中的 '违法行为' 工作表")
            logging.info("写入的内容如下：")
            for line in processed_lines:
                logging.info(line)
        else:
            logging.warning("处理结果为空，未写入Excel文件。")
    else:
        # 打印错误信息
        logging.error(f"处理文件 '{file_path}' 时出错：")
        logging.error(f"错误代码: {response.code}")
        logging.error(f"错误消息: {response.message}")

if __name__ == '__main__':
    # 指定包含.docx文件的文件夹路径
    directory_path = r'D:\Legal_text'
    process_docx_files_in_directory(directory_path)