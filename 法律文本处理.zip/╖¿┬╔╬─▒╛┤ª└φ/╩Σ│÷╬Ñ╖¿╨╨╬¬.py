from http import HTTPStatus
import dashscope
import os
from docx import Document

# 设置 dashscope API 密钥
dashscope.api_key = "sk-51d7c246db194b3a8784af888e0b8145"

def process_docx_files_in_directory(directory_path):
    # 检查指定路径是否存在
    if not os.path.exists(directory_path):
        print(f"路径 '{directory_path}' 不存在。")
        return

    # 遍历指定路径下的所有文件
    for filename in os.listdir(directory_path):
        if filename.endswith('.docx'):  # 只处理后缀为 .docx 的文件
            file_path = os.path.join(directory_path, filename)
            process_docx_file(file_path)

def process_docx_file(file_path):
    # 创建处理提示
    prompt = f"""你是一个法律文本处理人员，
会对我给你的文本进行处理。
输入：
将内容中的全部的违法行为整理出来，直接显示内容不需要详细到第几条和序号
举例输出：
**违法行为**:
* 
*

"""

    # 读取 .docx 文件内容
    doc = Document(file_path)
    text = '\n'.join([paragraph.text for paragraph in doc.paragraphs])

    # 将提示与文本内容结合
    prompt_with_text = f"{prompt}\n{text}"

    # 调用模型处理文本
    response = dashscope.Generation.call(
        model=dashscope.Generation.Models.qwen_turbo,
        prompt=prompt_with_text
    )

    # 检查响应状态码
    if response.status_code == HTTPStatus.OK:
        # 输出处理结果
        print(f"文件 '{file_path}' 处理结果：")
        # 仅输出文本内容，去除其他信息
        output_text = response.output.get('text', '')
        print(output_text)
    else:
        # 打印错误信息
        print(f"处理文件 '{file_path}' 时出错：")
        print(f"错误代码: {response.code}")
        print(f"错误消息: {response.message}")

if __name__ == '__main__':
    # 指定包含.docx文件的文件夹路径
    directory_path = r'D:\Legal_text'
    process_docx_files_in_directory(directory_path)