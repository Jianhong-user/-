import os

# 获取 "D:\Legal_text_result" 目录下的所有 Excel 文档
excel_files = [f for f in os.listdir("D:\Legal_text_result") if f.endswith(".xlsx")]

# 遍历 Excel 文档
for excel_file in excel_files:
    # 获取 Excel 文档的原名
    file_name, file_extension = os.path.splitext(excel_file)

    # 添加 "3-法律文本分析-" 字符串
    new_file_name = f"{file_name}{file_extension}"

    # 更新 Excel 文档的名称
    os.rename(os.path.join("D:\Legal_text_result", excel_file), os.path.join("D:\Legal_text_result", new_file_name))

    # 输出修改后的名称到控制台
