from selenium import webdriver
from PIL import Image
from PIL import ImageEnhance, ImageFilter
import time
import pytesseract
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium import webdriver
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

options = Options()
service = Service(r'C:\Program Files\Google\Chrome\Application\chromedriver.exe')

driver = webdriver.Chrome(service=service, options=options)


# 打开网页
driver.get('https://zxts.zjzwfw.gov.cn/zwmhww/#/home/index/public/more')

# 浏览器窗口最大化
wait = WebDriverWait(driver, 5)
driver.maximize_window()
inputElement = driver.find_element(By.CLASS_NAME, "ant-cascader-picker")
inputElement.click()
time.sleep(1.5)
second_element = driver.find_element(By.XPATH, "//div[@class='ant-cascader-menus-content']/ul[@class='ant-cascader-menu']/li[@class='ant-cascader-menu-item ant-cascader-menu-item-expand'][2]")
second_element.click()
time.sleep(1.5)
target_element = wait.until(EC.presence_of_element_located((By.XPATH, "//div[@class='ant-cascader-menus-content']/ul[@class='ant-cascader-menu'][2]//li[@class='ant-cascader-menu-item ant-cascader-menu-item-expand'][@title='浙江省宁波市海曙区']")))
target_element.click()
time.sleep(1.5)
date_input = wait.until(EC.presence_of_element_located((By.CLASS_NAME,  'ant-calendar-picker')))
date_input.click()
time.sleep(1.5)
link_text = "2023"
a_element = wait.until(EC.element_to_be_clickable((By.XPATH, f"//a[normalize-space(text())='{link_text}']")))
a_element.click()
time.sleep(1.5)
query_button = wait.until(EC.element_to_be_clickable((By.XPATH, "//button[@class='ant-btn ant-btn-primary ant-btn-two-chinese-chars' and contains(., '查询')]")))
query_button.click()
time.sleep(1.5)

# 获取当前页面总高度，用于计算滚动距离
last_height = driver.execute_script("return document.body.scrollHeight")

# 设定滚动次数或条件，这里以页面不再增长为停止条件
while True:
    # 滚动到当前页面高度的80%
    driver.execute_script("window.scrollTo(0, document.body.scrollHeight * 0.32);")
    a_text = 1
    for a_text in range(10):
        a_text += 1
        element_to_click = driver.find_element(By.XPATH, f"//a[normalize-space(text())='{a_text}']")
        element_to_click.click()
        for tage_index in range(1,11):
            tage_to_click = driver.find_element(By.XPATH, f"//tbody[@class='ant-table-tbody']/tr[{tage_index}]/td[1]")
            tage_to_click.click()
            time.sleep(2)
            driver.execute_script("window.scrollTo(0, document.body.scrollHeight * 0.25);")
            time.sleep(1.5)
            # 截取网页截图
            driver.save_screenshot('screenshot.png')

            # 使用 OCR 识别图片文字
            image = Image.open('screenshot.png')
            pytesseract.pytesseract.tesseract_cmd = r'D:\Python_environment\Tesseract_OCR\tesseract.exe'
            content_text = pytesseract.image_to_string(image, lang='chi_sim')  # 设置语言为简体中文

            # 处理识别结果
            print(content_text)
            time.sleep(1)
            driver.back()
            time.sleep(1)

        time.sleep(1)
        # 截取网页截图
        driver.save_screenshot('screenshot.png')

        # 使用 OCR 识别图片文字
        image = Image.open('screenshot.png')
        pytesseract.pytesseract.tesseract_cmd = r'D:\Python_environment\Tesseract_OCR\tesseract.exe'
        input_text = pytesseract.image_to_string(image, lang='chi_sim')  # 设置语言为简体中文

        # 处理识别结果
        print(input_text)
    # 等待页面加载新内容，时间视网络情况调整
    time.sleep(1)

    # 计算新的页面高度
    new_height = driver.execute_script("return document.body.scrollHeight")

    # 如果页面高度不再变化，说明滚动到底部，退出循环
    if new_height == last_height:
        break

    last_height = new_height


# 关闭浏览器
driver.quit()